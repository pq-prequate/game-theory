# Prequate engagement story — rebuilt, snazzier and more interactive

Turn the uploaded single-file HTML page into the app's home page (`/`), keeping the exact content, brand and structure, but rebuilt as real React components with a richer, more alive interaction layer.

## What stays exactly the same

- All copy, numbers, offices, four acts, the M&A callout, seven standing mandates, footer disclaimer.
- Brand identity: orange `#FF9633` / `#F96900`, ink `#161616`, warm tint `#FFF6EC`, Open Sans + Instrument Serif, the PRE/QUATE wordmark.
- Both existing modes: the scrollable story, and the 8-slide Presentation Mode with keyboard navigation.
- The "Talk to a partner" contact modal with its fields and success state.

## What gets snazzier

**Hero**
- Animated gradient orbs that drift and react subtly to cursor position.
- Headline reveals word-by-word; "enterprise value" gets an animated underline stroke.
- Stat counters ease up with an odometer feel when they enter view.

**Story spine**
- The month rail becomes a live scroll spine: the progress line fills as you read, the current month tick grows and glows, ticks jump to their act.
- Milestone cards animate in on scroll with a staggered lift, tilt slightly on hover, and carry an orange edge accent for the owning office.
- Act headers pin briefly as their section scrolls, so you always know which act you're in.

**Office filter**
- Filtering re-flows cards with smooth animated layout instead of a hard hide, dims non-matching acts, and shows a live count ("4 milestones · CFO Office").
- Filter state reflects in the URL so a filtered view can be shared.

**M&A callout**
- The six deal steps animate as a connected sequence, with the "45 days" figure counting up.

**Mandates and close**
- Cards reveal in sequence with a soft spotlight-follow hover on the dark section.
- CTA buttons get a magnetic hover and the primary button a subtle sheen.

**Presentation mode**
- Slide transitions with directional motion, animated journey-bar stops, arrow/space/Esc keys, plus swipe on touch.

**Polish everywhere**
- Scroll progress bar under the top nav; nav flips light/dark against the section behind it.
- Full reduced-motion fallback, visible keyboard focus states, mobile-first layout.
- Page title, description and social tags set for the story.

## Technical notes

- New home route at `src/routes/index.tsx`, replacing the placeholder, composed of section components under `src/components/story/` (Hero, MonthRail, OfficeFilter, Act, MilestoneCard, MACallout, Mandates, ContactModal, PresentationMode, Footer). Milestone/mandate/slide content lives in one typed data module.
- Design tokens (brand colors, fonts, radii) added to `src/styles.css` as semantic tokens; no hardcoded color utilities in components. Fonts loaded via `<link>` in `__root.tsx`.
- Motion via `motion/react` for reveals, layout animation on filtering, and slide transitions; scroll spine driven by scroll progress and IntersectionObserver.
- The contact form stays front-end only with the same success state, as in the uploaded file. Say the word if it should actually deliver email — that needs Lovable Cloud and can be a follow-up.