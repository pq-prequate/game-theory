Plan: Add a Sportstar Round emphasis callout to Act III

What we will build
- Refactor the existing hardcoded M&A / Corporate Development callout into a reusable `EmphasisCallout` component that is driven from data.
- Add a new full-width emphasis callout for the Sportstar Round, placed after the M12-M14 milestone cards in Act III, with the month set to M15.
- The callout uses the same dark, high-impact card treatment as the M&A callout and is associated with the Investment Banking Office so it works with the office filter.
- Keep the existing M12 Sportstar Round milestone card unchanged.
- Add a matching Sportstar Round slide to the presentation deck so the new emphasis is reflected in presentation mode.

Data and copy changes
- In `src/components/story/data.ts`, introduce a new `EmphasisCallout` type (eyebrow, heading, body, steps, stats, office, month) and replace the single `maCallout: boolean` flag with an `emphasisCallouts: EmphasisCallout[]` array on each act.
- Migrate the current M&A acquisition copy into the first emphasis callout entry under Act III.
- Add a second emphasis callout under Act III for the Sportstar Round with the provided copy: "We solicited the sports stars, set up the deal, stitched an accelerated value program from the association, negotiated the terms and defended the valuation case." The eyebrow becomes "Investment Banking Office · M15 · The Sportstar Round".

Component changes
- Convert `src/components/story/MACallout.tsx` into a generic `EmphasisCallout.tsx` that accepts the callout data as props.
- Update `src/components/story/ActSection.tsx` to render the `emphasisCallouts` array after the milestone cards, and apply filter dimming logic to each callout based on its office.

Filter and count changes
- Update the filter dimming in `ActSection` so an emphasis callout is visible when no filter is active, highlighted when its office matches the filter, and dimmed otherwise.
- Update the milestone count in `src/routes/index.tsx` to include the new Sportstar emphasis callout when Investment Banking is selected.

Presentation mode
- In `src/components/story/slides.tsx`, insert a new "Sportstar Round" slide after the M&A slide and before the existing Scale slide, using the same dark-card, step-grid treatment as the M&A slide.

Verification
- Confirm the new callout renders at M15 in Act III, below the M12-M14 milestone cards.
- Confirm the Investment Banking office filter highlights the new callout and the M12 Sportstar card.
- Confirm the presentation mode slide count and navigation still work.