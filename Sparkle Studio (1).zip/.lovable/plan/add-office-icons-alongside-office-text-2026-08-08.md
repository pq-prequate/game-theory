# Add office icons alongside office text

Add a Lucide line icon next to every office label in both the presentation mode and the main timeline.

## What changed

1. **Data model**  
   Extend `src/components/story/data.ts` so each office object carries a Lucide icon component (`Strategy`, `CFO`, `Investment Banking`, `Corp Dev`, `Franchise`, `Partnerships`, `Investor Relations`).

2. **Main timeline**  
   Render the icon next to the office text in:
   - `OfficeFilter.tsx` filter buttons
   - `MilestoneCard.tsx` office label chip
   - `EmphasisCallout.tsx` eyebrow
   - `Mandates.tsx` office cards

3. **Presentation mode**  
   Render the icon next to office labels in:
   - Slide eyebrows that list involved offices (e.g., "Act II · M06 – M09 · Investment Banking + Franchise + CFO + IR")
   - The "Today" slide grid of standing offices

4. **Styling**  
   Keep icons at 14–16px, inherit surrounding text color, and add a small gap between icon and label. No color changes; no text removal.

5. **Verify**  
   Confirm icons render correctly in both light and dark backgrounds, and that the timeline filter layout and card spacing remain intact.
