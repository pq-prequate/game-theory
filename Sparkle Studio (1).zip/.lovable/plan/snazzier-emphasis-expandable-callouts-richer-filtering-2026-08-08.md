# Snazzier emphasis, expandable callouts, richer filtering

## 1. Awesome Serif Italic as the emphasis typeface

Load the uploaded variable font `Awesome_Serif_Italic_VAR-VF.ttf` (plus the upright `Awesome_Serif_VAR-VF.ttf` as a companion) as CDN assets and register them with `@font-face` in `src/styles.css`, exposed as a `--font-emphasis` theme token.

Apply it to emphasis text only:
- Hero headline emphasis phrase ("enterprise value") — the circled phrase in the annotation — set in Awesome Serif Italic at the heaviest/extra variable axis setting, replacing Instrument Serif there.
- Emphasis callout headings (M&A, Sportstar) and the big act numerals.
- Large numeric stat values keep their current serif treatment unless the italic reads better at that size.

## 2. Interactive expanding callouts

`EmphasisCallout` becomes collapsible/expandable:
- Collapsed by default: eyebrow, heading, first two lines of body, and the step pills as a compact row.
- A clear "Expand" affordance (chevron + label) that toggles open with a height/opacity animation.
- Expanded: full body copy, the numbered steps rendered as a vertical stepped sequence with staggered reveal and a connecting progress line, plus the full stat grid.
- Keyboard accessible (button semantics, `aria-expanded`, Enter/Space), and respects reduced-motion.
- Only one callout expands at a time within an act; expanding scrolls it into view gently.

## 3. Hover animations

- Milestone cards: subtle pointer-tracked tilt plus a soft orange glow that follows the cursor, on top of the existing lift and left rule wipe.
- Emphasis callouts: ambient orange blur orb drifts toward the pointer; step pills brighten and shift on hover.
- Step pills and stat tiles: individual hover states (border to orange, slight scale).
- Filter buttons: fill sweep on hover.
- Hero stats: number lifts and its label brightens on hover.
- All hover motion disabled under `prefers-reduced-motion`.

## 4. Filter behavior update

Today filtering only fades non-matching items to 30% opacity, which leaves large empty greyed regions.

New behavior:
- Non-matching milestones and callouts are removed from the grid (with a Motion layout/exit animation) instead of being dimmed, so the timeline collapses to just the selected office's work.
- Acts with no matching items collapse to a slim, muted one-line stub ("Act II — no Investment Banking milestones") rather than rendering an empty section.
- Matching items animate into place with layout transitions and a brief orange highlight pulse.
- The filter bar shows the live count and gains an "All" reset chip alongside Clear.
- Month rail ticks for acts with no matches render muted.

## Technical notes

- Fonts registered via `lovable-assets` pointers, loaded with `@font-face` and `font-variation-settings` for the extra/heavy axis; no remote `@import` in CSS.
- Files touched: `src/styles.css`, `src/components/story/Hero.tsx`, `EmphasisCallout.tsx`, `MilestoneCard.tsx`, `ActSection.tsx`, `OfficeFilter.tsx`, `MonthRail.tsx`, `src/routes/index.tsx`.
- Presentation mode slides keep their current content; only the emphasis font carries over there.
