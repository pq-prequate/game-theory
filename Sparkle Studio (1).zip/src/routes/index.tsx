import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { TopBar } from "@/components/story/TopBar";
import { Hero } from "@/components/story/Hero";
import { MonthRail } from "@/components/story/MonthRail";
import { MobileMonthStrip } from "@/components/story/MobileMonthStrip";
import { OfficeFilter } from "@/components/story/OfficeFilter";
import { ActSection } from "@/components/story/ActSection";
import { Mandates } from "@/components/story/Mandates";
import { ContactModal } from "@/components/story/ContactModal";
import { PresentationMode } from "@/components/story/PresentationMode";
import { StoryFooter } from "@/components/story/StoryFooter";
import { acts, monthTicks, offices, type OfficeId } from "@/components/story/data";

const title = "Partners in enterprise value creation — Prequate Advisory";
const description =
  "A 24-month engagement story: two capital rounds, one 45-day acquisition, and seven standing operating mandates inside a venture-backed sports and gaming company.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "article" },
      { property: "og:url", content: "https://sports-tech-prequate.lovable.app/" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://sports-tech-prequate.lovable.app/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Article",
          headline: title,
          description,
          author: { "@type": "Organization", name: "Prequate Advisory" },
          publisher: { "@type": "Organization", name: "Prequate Advisory" },
          mainEntityOfPage: "https://sports-tech-prequate.lovable.app/",
        }),
      },
    ],
  }),
  component: Index,
});

function Index() {
  const [filter, setFilter] = useState<OfficeId | null>(null);
  const [presenting, setPresenting] = useState(false);
  const [contactOpen, setContactOpen] = useState(false);
  const [activeTick, setActiveTick] = useState(0);

  useEffect(() => {
    const param = new URLSearchParams(window.location.search).get("office");
    if (param && offices.some((o) => o.id === param)) setFilter(param as OfficeId);
  }, []);

  useEffect(() => {
    const url = new URL(window.location.href);
    if (filter) url.searchParams.set("office", filter);
    else url.searchParams.delete("office");
    window.history.replaceState({}, "", url);
  }, [filter]);

  useEffect(() => {
    const onScroll = () => {
      const total = document.body.scrollHeight - window.innerHeight;
      const p = total > 0 ? window.scrollY / total : 0;
      setActiveTick(Math.min(monthTicks.length - 1, Math.round(p * (monthTicks.length - 1))));
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const count = useMemo(
    () =>
      filter
        ? acts.reduce(
            (n, a) =>
              n +
              a.milestones.filter((m) => m.office === filter).length +
              (a.emphasisCallouts?.filter((c) => c.office === filter).length ?? 0),
            0,
          )
        : 0,
    [filter],
  );

  const mutedTargets = useMemo(() => {
    if (!filter) return [];
    return acts
      .filter(
        (a) =>
          !a.milestones.some((m) => m.office === filter) &&
          !(a.emphasisCallouts ?? []).some((c) => c.office === filter),
      )
      .map((a) => a.id);
  }, [filter]);

  return (
    <div className="bg-paper">
      <TopBar onPresent={() => setPresenting(true)} />
      <MonthRail activeIndex={activeTick} mutedTargets={mutedTargets} />
      <main>
        <Hero />
        <OfficeFilter active={filter} count={count} onChange={setFilter} />
        <MobileMonthStrip activeIndex={activeTick} mutedTargets={mutedTargets} />
        <div className="mx-auto max-w-6xl px-5 sm:px-8">
          {acts.map((act) => (
            <ActSection key={act.id} act={act} filter={filter} />
          ))}
        </div>
        <div className="border-t border-hairline bg-tint py-6 text-center">
          <span className="eyebrow text-grey/70">WHERE THE RELATIONSHIP STANDS</span>
        </div>
        <Mandates onContact={() => setContactOpen(true)} />
      </main>
      <StoryFooter />
      <PresentationMode
        open={presenting}
        onClose={() => setPresenting(false)}
        onContact={() => {
          setPresenting(false);
          setContactOpen(true);
        }}
      />
      <ContactModal open={contactOpen} onClose={() => setContactOpen(false)} />
    </div>
  );
}
