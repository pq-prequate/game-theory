import { motion, useMotionTemplate, useMotionValue, useReducedMotion, useSpring } from "motion/react";
import { CountUp } from "./CountUp";
import { offices } from "./data";
import type { Milestone } from "./data";

export function MilestoneCard({
  m,
  highlight = false,
  index = 0,
}: {
  m: Milestone;
  highlight?: boolean;
  index?: number;
}) {
  const reduce = useReducedMotion();
  const office = offices.find((o) => o.id === m.office);
  const mx = useMotionValue(50);
  const my = useMotionValue(50);
  const rx = useSpring(useMotionValue(0), { stiffness: 200, damping: 20 });
  const ry = useSpring(useMotionValue(0), { stiffness: 200, damping: 20 });
  const glow = useMotionTemplate`radial-gradient(220px circle at ${mx}% ${my}%, rgba(249,105,0,0.13), transparent 70%)`;

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 22 }}
      whileInView={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -12, scale: 0.97 }}
      viewport={{ once: true, margin: "-8% 0px" }}
      transition={{ duration: 0.5, ease: "easeOut", delay: Math.min(index, 5) * 0.07 }}
      style={reduce ? {} : { rotateX: rx, rotateY: ry, transformPerspective: 900 }}
      onPointerMove={(e) => {
        if (reduce) return;
        const r = e.currentTarget.getBoundingClientRect();
        const px = (e.clientX - r.left) / r.width;
        const py = (e.clientY - r.top) / r.height;
        mx.set(px * 100);
        my.set(py * 100);
        rx.set((0.5 - py) * 5);
        ry.set((px - 0.5) * 5);
      }}
      onPointerLeave={() => {
        rx.set(0);
        ry.set(0);
      }}
      className={`group relative overflow-hidden rounded-xl border bg-paper p-6 transition-all duration-300 hover:-translate-y-1 hover:border-orange/60 hover:shadow-[0_18px_40px_-24px_rgba(22,22,22,0.35)] ${
        highlight ? "border-orange/50 shadow-[0_0_0_3px_rgba(255,150,51,0.14)]" : "border-hairline"
      }`}
    >
      <motion.span
        aria-hidden
        style={{ backgroundImage: glow }}
        className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-300 group-hover:opacity-100"
      />
      <span className="absolute inset-y-0 left-0 w-[3px] origin-top scale-y-0 bg-orange-deep transition-transform duration-300 group-hover:scale-y-100" />
      <div className="relative flex flex-wrap items-center gap-2">
        <span className="eyebrow rounded bg-tint px-2 py-1 text-[10px] text-orange-deep">
          {m.month}
        </span>
        <span className="eyebrow inline-flex items-center gap-1.5 text-[10px] text-grey/70">
          {office && <office.icon className="size-3.5" />}
          {m.officeLabel}
        </span>
        {m.tag && (
          <span className="eyebrow rounded-full border border-hairline px-2 py-0.5 text-[9px] text-grey/60">
            {m.tag}
          </span>
        )}
      </div>
      {m.metric && (
        <div className="relative mt-5">
          <div className="emphasis text-[clamp(30px,4vw,44px)] leading-none text-orange-deep transition-transform duration-300 group-hover:-translate-y-0.5">
            <CountUp
              value={m.metric.value}
              prefix={m.metric.prefix}
              suffix={m.metric.suffix}
            />
          </div>
          <div className="eyebrow mt-2 text-[10px] text-grey/70">{m.metric.label}</div>
        </div>
      )}
      <h3 className="relative mt-4 text-lg font-semibold text-ink">{m.title}</h3>
      <p className="relative mt-2 text-sm leading-relaxed text-grey">{m.body}</p>
    </motion.article>
  );
}