import { motion, useScroll, useSpring } from "motion/react";
import { Play } from "lucide-react";
import { Wordmark } from "./Wordmark";

const links = [
  { href: "#act-1", label: "Act I" },
  { href: "#act-2", label: "Act II" },
  { href: "#act-3", label: "Act III" },
  { href: "#act-4", label: "Act IV" },
  { href: "#mandates", label: "Today" },
];

export function TopBar({ onPresent }: { onPresent: () => void }) {
  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, { stiffness: 120, damping: 30, mass: 0.3 });

  return (
    <header className="fixed inset-x-0 top-0 z-80 h-[62px] border-b border-paper/10 bg-ink/70 backdrop-blur-xl backdrop-saturate-150">
      <div className="flex h-full items-center justify-between px-5 sm:px-8">
        <Wordmark dark />
        <nav className="hidden gap-6 md:flex">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="eyebrow text-xs text-paper/60 no-underline transition-colors hover:text-orange"
            >
              {l.label}
            </a>
          ))}
        </nav>
        <button
          onClick={onPresent}
          className="sheen flex items-center gap-2 rounded-full border border-paper/35 px-4 py-2 text-[11px] font-semibold tracking-[0.12em] text-paper uppercase transition-colors hover:border-orange-deep hover:bg-orange-deep sm:px-5"
        >
          <Play className="size-3" /> Present
        </button>
      </div>
      <motion.div
        style={{ scaleX: progress }}
        className="h-px origin-left bg-orange"
        aria-hidden
      />
    </header>
  );
}