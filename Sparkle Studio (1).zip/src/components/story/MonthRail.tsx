import { motion, useScroll, useSpring } from "motion/react";
import { monthTicks } from "./data";

export function MonthRail({
  activeIndex,
  mutedTargets = [],
}: {
  activeIndex: number;
  mutedTargets?: string[];
}) {
  const { scrollYProgress } = useScroll();
  const fill = useSpring(scrollYProgress, { stiffness: 100, damping: 30, mass: 0.3 });

  return (
    <div className="pointer-events-none fixed top-1/2 left-4 z-70 hidden -translate-y-1/2 xl:block">
      <div className="relative flex h-[52vh] flex-col justify-between">
        <div className="absolute top-0 bottom-0 left-[5px] w-px bg-hairline" />
        <motion.div
          style={{ scaleY: fill }}
          className="absolute top-0 bottom-0 left-[5px] w-px origin-top bg-orange"
        />
        {monthTicks.map((t, i) => {
          const muted = mutedTargets.includes(t.target);
          return (
          <button
            key={t.label}
            onClick={() => document.getElementById(t.target)?.scrollIntoView({ block: "start" })}
            className={`group pointer-events-auto relative flex items-center gap-3 text-left transition-opacity duration-300 ${
              muted ? "opacity-30" : "opacity-100"
            }`}
          >
            <span
              className={`relative z-10 block size-[11px] rounded-full border transition-all duration-300 ${
                i <= activeIndex && !muted
                  ? "scale-110 border-orange bg-orange shadow-[0_0_0_4px_rgba(255,150,51,0.18)]"
                  : "border-hairline bg-paper"
              }`}
            />
            <span
              className={`eyebrow text-[10px] transition-all duration-300 ${
                i <= activeIndex && !muted
                  ? "text-orange-deep"
                  : "text-grey/50 group-hover:text-grey"
              }`}
            >
              {t.label}
            </span>
          </button>
          );
        })}
      </div>
    </div>
  );
}