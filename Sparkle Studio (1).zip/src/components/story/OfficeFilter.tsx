import { X } from "lucide-react";
import { offices, type OfficeId } from "./data";

export function OfficeFilter({
  active,
  count,
  onChange,
}: {
  active: OfficeId | null;
  count: number;
  onChange: (o: OfficeId | null) => void;
}) {
  const activeLabel = offices.find((o) => o.id === active)?.label;

  return (
    <div className="sticky top-[62px] z-60 border-b border-hairline bg-paper/90 backdrop-blur-xl">
      <div className="scrollbar-none mx-auto flex max-w-6xl items-center gap-2 overflow-x-auto px-5 py-3 sm:px-8">
        <span className="eyebrow mr-1 whitespace-nowrap text-grey/70">
          {active ? `${count} milestones · ${activeLabel} Office` : "Filter by office"}
        </span>
        <button
          onClick={() => onChange(null)}
          className={`rounded-full border px-4 py-1.5 text-xs font-semibold whitespace-nowrap transition-all ${
            active === null
              ? "border-ink bg-ink text-paper"
              : "border-hairline text-grey hover:border-orange hover:text-ink"
          }`}
        >
          All
        </button>
        {offices.map((o) => (
          <button
            key={o.id}
            onClick={() => onChange(active === o.id ? null : o.id)}
            className={`sheen inline-flex items-center gap-1.5 rounded-full border px-4 py-1.5 text-xs font-semibold whitespace-nowrap transition-all hover:-translate-y-0.5 ${
              active === o.id
                ? "border-orange-deep bg-orange-deep text-paper"
                : "border-hairline text-grey hover:border-orange hover:text-ink"
            }`}
          >
            <o.icon className="size-3.5" />
            {o.label}
          </button>
        ))}
        {active && (
          <button
            onClick={() => onChange(null)}
            className="ml-1 flex items-center gap-1 text-xs font-semibold whitespace-nowrap text-grey underline-offset-4 hover:text-orange-deep hover:underline"
          >
            <X className="size-3" /> Clear
          </button>
        )}
      </div>
    </div>
  );
}