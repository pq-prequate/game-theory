import { motion } from "motion/react";
import { mandates, offices } from "./data";

export function Mandates({ onContact }: { onContact: () => void }) {
  return (
    <section id="mandates" className="scroll-mt-24 bg-ink py-20 sm:py-28">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <p className="eyebrow text-orange">Seven standing mandates · Month 24</p>
        <h2 className="mt-5 text-[clamp(32px,5vw,64px)] leading-tight font-light text-paper">
          We stay until it is done.
        </h2>
        <p className="mt-5 max-w-2xl text-[15px] leading-relaxed text-paper/55">
          Most advisors leave a report. Twenty-four months in, we run seven offices inside this
          business. These are not retainers. They are operating mandates, each one with a number
          attached to it.
        </p>

        <div className="mt-14 grid gap-px overflow-hidden rounded-2xl border border-paper/10 bg-paper/10 sm:grid-cols-2 lg:grid-cols-3">
          {mandates.map((m, i) => (
            <motion.div
              key={m.office}
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-6% 0px" }}
              transition={{ delay: i * 0.07, duration: 0.5 }}
              className={`group relative bg-ink p-6 transition-colors hover:bg-ink-soft ${
                i === mandates.length - 1 ? "sm:col-span-2 lg:col-span-3" : ""
              }`}
            >
              {(() => {
                const office = offices.find((o) => o.id === m.officeId);
                return (
                  <div className="eyebrow inline-flex items-center gap-1.5 text-orange">
                    {office && <office.icon className="size-3.5" />}
                    {m.office}
                  </div>
                );
              })()}
              <p className="mt-3 text-sm leading-relaxed text-paper/55">{m.body}</p>
              <span className="mt-4 block h-px w-0 bg-orange transition-all duration-500 group-hover:w-16" />
            </motion.div>
          ))}
        </div>

        <div className="mt-14 flex flex-wrap items-center gap-4">
          <button
            onClick={onContact}
            className="sheen rounded-full bg-orange-deep px-7 py-3.5 text-xs font-semibold tracking-[0.12em] text-paper uppercase transition-transform hover:-translate-y-0.5"
          >
            Talk to a partner
          </button>
          <a
            href="#top"
            className="rounded-full border border-paper/25 px-7 py-3.5 text-xs font-semibold tracking-[0.12em] text-paper/80 uppercase no-underline transition-colors hover:border-orange hover:text-orange"
          >
            Read the story again
          </a>
        </div>
        <p className="mt-6 text-sm text-paper/40">
          Or write to our CEO directly:{" "}
          <a href="mailto:ag@prequate.one" className="text-orange no-underline hover:underline">
            ag@prequate.one
          </a>
          <span className="mx-3 opacity-30">·</span>
          <a
            href="https://www.prequateadvisory.com"
            target="_blank"
            rel="noopener"
            className="text-orange no-underline hover:underline"
          >
            www.prequateadvisory.com
          </a>
        </p>
      </div>
    </section>
  );
}