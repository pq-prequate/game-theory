export function Wordmark({ dark = false }: { dark?: boolean }) {
  return (
    <a
      href="#top"
      className="text-sm font-bold tracking-[0.07em] whitespace-nowrap no-underline"
    >
      <span className={dark ? "text-paper/70" : "text-grey"}>PRE</span>
      <span className="text-orange-deep">QUATE</span>
    </a>
  );
}