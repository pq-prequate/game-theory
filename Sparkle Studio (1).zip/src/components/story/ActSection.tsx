import { AnimatePresence, motion } from "motion/react";
import { MilestoneCard } from "./MilestoneCard";
import { EmphasisCallout } from "./EmphasisCallout";
import { offices, type Act, type OfficeId } from "./data";

export function ActSection({ act, filter }: { act: Act; filter: OfficeId | null }) {
  const milestones = filter ? act.milestones.filter((m) => m.office === filter) : act.milestones;
  const callouts = (act.emphasisCallouts ?? []).filter((c) => !filter || c.office === filter);
  const empty = milestones.length === 0 && callouts.length === 0;
  const officeLabel = offices.find((o) => o.id === filter)?.label;

  if (empty) {
    return (
      <motion.section
        id={act.id}
        layout
        className="scroll-mt-32 border-t border-hairline py-5"
      >
        <div className="flex items-center gap-3">
          <span className="font-serif text-lg leading-none text-grey/40">{act.numeral}</span>
          <span className="eyebrow text-[10px] text-grey/40">
            Act {act.numeral} · no {officeLabel} milestones
          </span>
        </div>
      </motion.section>
    );
  }

  return (
    <motion.section
      id={act.id}
      layout
      className="scroll-mt-32 border-t border-hairline py-16 sm:py-24"
    >
      <div className="grid gap-8 lg:grid-cols-[1fr_1.1fr] lg:gap-16">
        <div className="lg:sticky lg:top-32 lg:self-start">
          <div className="flex items-center gap-3">
            <span className="emphasis text-5xl leading-none text-orange">{act.numeral}</span>
            <span className="eyebrow text-grey/60">{act.span}</span>
          </div>
          <motion.h2
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-5 text-[clamp(26px,3.6vw,44px)] leading-tight font-light text-ink"
          >
            {act.heading}
          </motion.h2>
        </div>
        <p className="text-[15px] leading-relaxed text-grey lg:pt-3">{act.intro}</p>
      </div>

      <div className="relative mt-12">
        <div
          aria-hidden
          className="absolute top-0 bottom-0 left-[7px] w-px bg-hairline md:hidden"
        />
        <motion.div
          aria-hidden
          initial={{ scaleY: 0 }}
          whileInView={{ scaleY: 1 }}
          viewport={{ once: true, margin: "-20% 0px" }}
          transition={{ duration: 1.1, ease: "easeOut" }}
          className="absolute top-0 bottom-0 left-[7px] w-px origin-top bg-orange/70 md:hidden"
        />
        <motion.div layout className="grid gap-5 pl-7 md:grid-cols-2 md:pl-0">
          <AnimatePresence mode="popLayout" initial={false}>
            {milestones.map((m, i) => (
              <div key={`${m.month}-${m.title}`} className="relative">
                <motion.span
                  aria-hidden
                  initial={{ scale: 0, opacity: 0 }}
                  whileInView={{ scale: 1, opacity: 1 }}
                  viewport={{ once: true, margin: "-10% 0px" }}
                  transition={{ delay: 0.1 + i * 0.06, type: "spring", stiffness: 320, damping: 18 }}
                  className="absolute top-7 -left-[27px] size-[9px] rounded-full border-2 border-paper bg-orange-deep md:hidden"
                />
                <MilestoneCard m={m} highlight={!!filter} index={i} />
              </div>
            ))}
            {callouts.map((c) => (
              <EmphasisCallout key={c.month} callout={c} highlight={!!filter} />
            ))}
          </AnimatePresence>
        </motion.div>
      </div>
    </motion.section>
  );
}
