import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { slides } from "./slides";
import { Wordmark } from "./Wordmark";

export function PresentationMode({
  open,
  onClose,
  onContact,
}: {
  open: boolean;
  onClose: () => void;
  onContact: () => void;
}) {
  const [[index, dir], setState] = useState<[number, number]>([0, 1]);
  const touchX = useRef(0);

  const go = useCallback((next: number) => {
    setState(([cur]) => {
      const wrapped = (next + slides.length) % slides.length;
      return [wrapped, wrapped > cur ? 1 : -1];
    });
  }, []);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight" || e.key === " ") {
        e.preventDefault();
        setState(([cur]) => [(cur + 1) % slides.length, 1]);
      }
      if (e.key === "ArrowLeft") setState(([cur]) => [(cur - 1 + slides.length) % slides.length, -1]);
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  const slide = slides[index]!;

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-90 flex flex-col bg-ink"
          role="dialog"
          aria-modal="true"
          aria-label="Presentation mode"
          onTouchStart={(e) => (touchX.current = e.touches[0]!.clientX)}
          onTouchEnd={(e) => {
            const dx = e.changedTouches[0]!.clientX - touchX.current;
            if (Math.abs(dx) > 60) go(index + (dx < 0 ? 1 : -1));
          }}
        >
          <div className="relative h-[3px] w-full bg-paper/10">
            <motion.div
              className="absolute inset-y-0 left-0 bg-orange"
              animate={{ width: `${((index + 1) / slides.length) * 100}%` }}
              transition={{ type: "spring", stiffness: 120, damping: 24 }}
            />
          </div>

          <div className="scrollbar-none flex items-center gap-4 overflow-x-auto px-5 py-3 sm:px-8">
            {slides.map((s, i) => (
              <button
                key={s.key}
                onClick={() => go(i)}
                className={`eyebrow text-[10px] whitespace-nowrap transition-colors ${
                  i === index ? "text-orange" : "text-paper/30 hover:text-paper/60"
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>

          <div className="flex items-center justify-between border-y border-paper/10 px-5 py-3 sm:px-8">
            <Wordmark dark />
            <span className="eyebrow text-[10px] text-paper/35">
              {index + 1} / {slides.length}
            </span>
            <button
              onClick={onClose}
              className="eyebrow text-[10px] text-paper/60 transition-colors hover:text-orange"
            >
              Esc · Exit
            </button>
          </div>

          <div className="relative flex-1 overflow-y-auto">
            <AnimatePresence mode="wait" custom={dir}>
              <motion.div
                key={slide.key}
                initial={{ opacity: 0, x: dir * 60 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: dir * -60 }}
                transition={{ duration: 0.35, ease: "easeOut" }}
                className="mx-auto max-w-5xl px-5 py-10 sm:px-8 sm:py-14"
              >
                <p className="eyebrow text-orange">{slide.eyebrow}</p>
                <h2 className="mt-5 text-[clamp(30px,5vw,64px)] leading-[1.08] font-light text-paper">
                  {slide.heading}
                </h2>
                {slide.sub && (
                  <p className="mt-5 max-w-3xl text-[15px] leading-relaxed text-paper/55">
                    {slide.sub}
                  </p>
                )}
                {slide.points && (
                  <ul className="mt-8 space-y-3">
                    {slide.points.map((p, i) => (
                      <motion.li
                        key={i}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.1 + i * 0.08 }}
                        className="border-l-2 border-orange/40 pl-4 text-sm leading-relaxed text-paper/60 [&_strong]:font-semibold [&_strong]:text-paper"
                      >
                        {p}
                      </motion.li>
                    ))}
                  </ul>
                )}
                {slide.render?.()}
                {slide.key === "contact" && (
                  <div className="mt-10 space-y-6">
                    <div className="h-px w-24 bg-orange" />
                    <div className="flex flex-wrap items-center gap-4 text-sm">
                      <span className="eyebrow text-[10px] text-paper/35">
                        Start the conversation
                      </span>
                      <a href="mailto:ag@prequate.one" className="text-orange no-underline">
                        ag@prequate.one
                      </a>
                      <a
                        href="https://www.prequateadvisory.com"
                        target="_blank"
                        rel="noopener"
                        className="text-orange no-underline"
                      >
                        www.prequateadvisory.com
                      </a>
                    </div>
                    <button
                      onClick={onContact}
                      className="sheen rounded-full bg-orange-deep px-7 py-3.5 text-xs font-semibold tracking-[0.12em] text-paper uppercase"
                    >
                      Talk to a partner
                    </button>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
          </div>

          <div className="flex items-center justify-between border-t border-paper/10 px-5 py-4 sm:px-8">
            <div className="flex gap-2">
              {slides.map((s, i) => (
                <button
                  key={s.key}
                  onClick={() => go(i)}
                  aria-label={`Slide ${i + 1}`}
                  className={`h-1.5 rounded-full transition-all ${
                    i === index ? "w-6 bg-orange" : "w-1.5 bg-paper/25 hover:bg-paper/50"
                  }`}
                />
              ))}
            </div>
            <span className="hidden text-[11px] text-paper/30 sm:block">
              ← → arrow keys · Space to advance
            </span>
            <div className="flex gap-2">
              <button
                onClick={() => go(index - 1)}
                aria-label="Previous slide"
                className="rounded-full border border-paper/20 p-2 text-paper/70 transition-colors hover:border-orange hover:text-orange"
              >
                <ArrowLeft className="size-4" />
              </button>
              <button
                onClick={() => go(index + 1)}
                aria-label="Next slide"
                className="rounded-full border border-paper/20 p-2 text-paper/70 transition-colors hover:border-orange hover:text-orange"
              >
                <ArrowRight className="size-4" />
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}