import { useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { Check, X } from "lucide-react";

const field =
  "w-full rounded-lg border border-hairline bg-paper px-4 py-3 text-sm text-ink outline-none transition-colors focus:border-orange-deep";

export function ContactModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [sent, setSent] = useState(false);

  const close = () => {
    onClose();
    setTimeout(() => setSent(false), 300);
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={(e) => e.target === e.currentTarget && close()}
          className="fixed inset-0 z-100 flex items-start justify-center overflow-y-auto bg-ink/70 p-4 backdrop-blur-sm sm:items-center"
          role="dialog"
          aria-modal="true"
          aria-label="Talk to a partner"
        >
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 16, scale: 0.98 }}
            transition={{ type: "spring", stiffness: 260, damping: 26 }}
            className="relative my-8 w-full max-w-2xl rounded-2xl bg-paper p-7 sm:p-10"
          >
            <button
              onClick={close}
              aria-label="Close"
              className="absolute top-5 right-5 text-grey transition-colors hover:text-ink"
            >
              <X className="size-5" />
            </button>

            {sent ? (
              <div className="py-12 text-center">
                <motion.div
                  initial={{ scale: 0.6, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="mx-auto flex size-14 items-center justify-center rounded-full bg-orange-deep text-paper"
                >
                  <Check className="size-7" />
                </motion.div>
                <h3 className="mt-6 font-serif text-3xl text-ink">Sent.</h3>
                <p className="mx-auto mt-3 max-w-sm text-sm text-grey">
                  A partner will come back to you within one working day at the email you provided.
                </p>
              </div>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  setSent(true);
                }}
              >
                <p className="eyebrow text-orange-deep">Partners in enterprise value creation</p>
                <h2 className="mt-3 text-[clamp(26px,3.4vw,40px)] leading-tight font-light text-ink">
                  Talk to a partner.
                </h2>
                <p className="mt-3 text-sm text-grey">
                  Tell us a little about your business. A partner will come back to you within one
                  working day.
                </p>

                <div className="mt-7 space-y-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <label className="block">
                      <span className="eyebrow text-[10px] text-grey">Your name</span>
                      <input required placeholder="Full name" className={`mt-2 ${field}`} />
                    </label>
                    <label className="block">
                      <span className="eyebrow text-[10px] text-grey">Company</span>
                      <input required placeholder="Company name" className={`mt-2 ${field}`} />
                    </label>
                  </div>
                  <label className="block">
                    <span className="eyebrow text-[10px] text-grey">Email</span>
                    <input
                      required
                      type="email"
                      placeholder="you@company.com"
                      className={`mt-2 ${field}`}
                    />
                  </label>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <label className="block">
                      <span className="eyebrow text-[10px] text-grey">Revenue range</span>
                      <select required defaultValue="" className={`mt-2 ${field}`}>
                        <option value="" disabled>
                          Select range
                        </option>
                        <option>Under ₹100 crore</option>
                        <option>₹100 – 500 crore</option>
                        <option>₹500 – 2,000 crore</option>
                        <option>Above ₹2,000 crore</option>
                      </select>
                    </label>
                    <label className="block">
                      <span className="eyebrow text-[10px] text-grey">What you need</span>
                      <select required defaultValue="" className={`mt-2 ${field}`}>
                        <option value="" disabled>
                          Select area
                        </option>
                        <option>Growth</option>
                        <option>Efficiency</option>
                        <option>Transactions (fundraise / M&amp;A)</option>
                        <option>Portfolio value</option>
                        <option>Not sure yet</option>
                      </select>
                    </label>
                  </div>
                  <label className="block">
                    <span className="eyebrow text-[10px] text-grey">
                      One line on the situation (optional)
                    </span>
                    <textarea
                      rows={3}
                      placeholder="What is the problem or opportunity you are working on?"
                      className={`mt-2 ${field}`}
                    />
                  </label>
                </div>

                <button
                  type="submit"
                  className="sheen mt-7 w-full rounded-full bg-ink px-7 py-3.5 text-xs font-semibold tracking-[0.12em] text-paper uppercase transition-colors hover:bg-orange-deep"
                >
                  Send to a partner
                </button>
                <p className="mt-3 text-center text-xs text-grey/70">
                  Sent to ag@prequate.one · We do not share your details.
                </p>
              </form>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}