import { motion, useScroll, useSpring } from "motion/react";
import { monthTicks } from "./data";

export function MobileMonthStrip({
  activeIndex,
  mutedTargets = [],
}: {
  activeIndex: number;
  mutedTargets?: string[];
}) {
  const { scrollYProgress } = useScroll();
  const fill = useSpring(scrollYProgress, { stiffness: 100, damping: 30, mass: 0.3 });

  return (
    <div className="sticky top-[110px] z-50 border-b border-hairline bg-paper/90 backdrop-blur-xl xl:hidden">
      <div className="scrollbar-none mx-auto flex max-w-6xl items-center gap-1 overflow-x-auto px-5 py-2 sm:px-8">
        {monthTicks.map((t, i) => {
          const muted = mutedTargets.includes(t.target);
          const done = i <= activeIndex && !muted;
          return (
            <button
              key={t.label}
              onClick={() => document.getElementById(t.target)?.scrollIntoView({ block: "start" })}
              className={`relative flex shrink-0 items-center gap-1.5 rounded-full px-2 py-1 transition-opacity duration-300 ${
                muted ? "opacity-30" : "opacity-100"
              }`}
            >
              <motion.span
                animate={{ scale: done ? 1.15 : 1 }}
                transition={{ type: "spring", stiffness: 320, damping: 20 }}
                className={`block size-2 rounded-full border ${
                  done ? "border-orange bg-orange" : "border-hairline bg-paper"
                }`}
              />
              <span
                className={`eyebrow text-[9px] transition-colors duration-300 ${
                  done ? "text-orange-deep" : "text-grey/50"
                }`}
              >
                {t.label}
              </span>
            </button>
          );
        })}
      </div>
      <motion.div style={{ scaleX: fill }} className="h-px origin-left bg-orange" aria-hidden />
    </div>
  );
}
