import type { ReactNode } from "react";
import { offices, type OfficeId } from "./data";

export type Slide = {
  key: string;
  label: string;
  eyebrow: ReactNode;
  heading: ReactNode;
  sub?: string;
  render?: () => ReactNode;
  points?: ReactNode[];
};

function OfficeLabel({ id, name }: { id: OfficeId; name?: string }) {
  const o = offices.find((o) => o.id === id);
  return (
    <span className="inline-flex items-center gap-1">
      {o && <o.icon className="size-3.5" />}
      {name ?? o?.label}
    </span>
  );
}

const statCells = [
  { n: "24", l: "Months" },
  { n: "7", l: "Offices" },
  { n: "$3.75m", l: "Capital raised" },
  { n: "45", l: "M&A days" },
];

export const slides: Slide[] = [
  {
    key: "intro",
    label: "Intro",
    eyebrow: "Sports & Gaming · 24-month engagement",
    heading: (
      <>
        Partners in <em className="font-serif italic text-orange">enterprise value</em> creation.
      </>
    ),
    sub: "One venture. One firm. Month zero to month twenty-four. Two capital rounds, one acquisition, seven standing offices. This is not a case study. It is an engagement that is still running.",
    render: () => (
      <div className="mt-10 grid max-w-2xl grid-cols-2 overflow-hidden rounded-xl border border-paper/10 sm:grid-cols-4">
        {statCells.map((s, i) => (
          <div
            key={s.l}
            className={`px-6 py-5 ${i < statCells.length - 1 ? "border-r border-paper/10" : ""}`}
          >
            <div className="font-serif text-4xl leading-none text-orange">{s.n}</div>
            <div className="eyebrow mt-2 text-[10px] text-paper/30">{s.l}</div>
          </div>
        ))}
      </div>
    ),
  },
  {
    key: "blueprint",
    label: "Blueprint",
    eyebrow: (
      <span className="inline-flex flex-wrap items-center gap-1">
        <span>Act I · M00 – M06 ·</span>
        <OfficeLabel id="strategy" />
        <span>+</span>
        <OfficeLabel id="cfo" />
      </span>
    ),
    heading: "Build the plan. Then the business.",
    sub: "Most businesses raise money, then figure out the plan. We wrote the blueprint before a single centre opened or a rupee was raised.",
    points: [
      <>
        <strong>Business blueprint:</strong> market structure, unit economics, 24-month sequence of
        moves
      </>,
      <>
        <strong>Rollout strategy:</strong> locations, formats, order, and the numbers each opening
        must hit
      </>,
      <>
        <strong>Annual operating plan:</strong> one financial model behind every decision the
        founders make
      </>,
      <>
        <strong>Discipline first:</strong> the plan gave the company something to defend in any
        investor room
      </>,
    ],
  },
  {
    key: "capital",
    label: "Capital",
    eyebrow: (
      <span className="inline-flex flex-wrap items-center gap-1">
        <span>Act II · M06 – M09 ·</span>
        <OfficeLabel id="ib" />
        <span>+</span>
        <OfficeLabel id="franchise" />
        <span>+</span>
        <OfficeLabel id="cfo" />
        <span>+</span>
        <OfficeLabel id="ir" />
      </span>
    ),
    heading: "Raise capital. Build the machine behind it.",
    sub: "Capital is necessary. What you do with the 90 days after the close is what separates the companies that scale from the ones that stall.",
    render: () => (
      <div className="mt-8 grid gap-8 lg:grid-cols-2">
        <div className="flex flex-wrap gap-2">
          {[
            "Negotiation",
            "Structuring",
            "Valuation defence",
            "Diligence",
            "IR takeover",
            "Franchise model",
          ].map((b) => (
            <span
              key={b}
              className="rounded-full border border-paper/15 px-4 py-1.5 text-xs font-semibold tracking-wide text-paper/70"
            >
              {b}
            </span>
          ))}
        </div>
        <div className="space-y-4">
          {[
            { n: "$2.5m", serif: true, l: "Pre-Series A · Rainmatter + WEH · M06" },
            { n: "Franchise model built", l: "Non-dilutive scale mechanism · M08" },
            { n: "Financial operating excellence", l: "Reporting and controls installed · M09" },
            { n: "Investor relations taken over", l: "One narrative, managed centrally · M09" },
          ].map((r) => (
            <div key={r.l} className="border-l-2 border-orange/60 pl-4">
              <div
                className={
                  r.serif
                    ? "font-serif text-4xl leading-none text-orange"
                    : "text-lg font-semibold text-paper"
                }
              >
                {r.n}
              </div>
              <div className="eyebrow mt-1.5 text-[10px] text-paper/35">{r.l}</div>
            </div>
          ))}
        </div>
      </div>
    ),
  },
  {
    key: "ma",
    label: "M&A",
    eyebrow: (
      <span className="inline-flex items-center gap-1.5">
        <OfficeLabel id="corpdev" />
        <span>· M10 · The acquisition</span>
      </span>
    ),
    heading: (
      <>
        One acquisition. <em className="font-serif italic text-orange">45 days,</em> start to close.
      </>
    ),
    sub: "An AI-native sports technology platform. We sourced the asset, aligned both founding teams on vision, structured the deal, ran diligence, and delivered the integration. No gaps in ownership across six phases. No advisor sitting out a phase.",
    render: () => (
      <div className="mt-8 grid max-w-4xl grid-cols-2 gap-px overflow-hidden rounded-xl border border-paper/10 bg-paper/10 sm:grid-cols-3 lg:grid-cols-6">
        {[
          "Asset sourcing",
          "Vision alignment",
          "Negotiation",
          "Deal structure",
          "Diligence",
          "Integration",
        ].map((s, i) => (
          <div key={s} className="bg-ink px-4 py-5 text-center">
            <div className="eyebrow mb-2 text-[10px] text-orange">
              {String(i + 1).padStart(2, "0")}
            </div>
            <div className="text-[13px] font-semibold text-paper/70">{s}</div>
          </div>
        ))}
      </div>
    ),
  },
  {
    key: "sportstar",
    label: "Sportstar",
    eyebrow: (
      <span className="inline-flex items-center gap-1.5">
        <OfficeLabel id="ib" />
        <span>· M15 · The Sportstar Round</span>
      </span>
    ),
    heading: (
      <>
        A round anchored by top-ranked athletes,{" "}
        <em className="font-serif italic text-orange">on commercial terms.</em>
      </>
    ),
    sub: "We solicited the sports stars, set up the deal, stitched an accelerated value program from the association, negotiated the terms and defended the valuation case. India's top-ranked athletes across four sports came in at the same valuation, not as brand endorsers or equity-for-promotion arrangements.",
    render: () => (
      <div className="mt-8 grid max-w-4xl grid-cols-2 gap-px overflow-hidden rounded-xl border border-paper/10 bg-paper/10 sm:grid-cols-3 lg:grid-cols-5">
        {[
          "Solicited the sports stars",
          "Set up the deal",
          "Stitched an accelerated value program",
          "Negotiated the terms",
          "Defended the valuation case",
        ].map((s, i) => (
          <div key={s} className="bg-ink px-4 py-5 text-center">
            <div className="eyebrow mb-2 text-[10px] text-orange">
              {String(i + 1).padStart(2, "0")}
            </div>
            <div className="text-[13px] font-semibold text-paper/70">{s}</div>
          </div>
        ))}
      </div>
    ),
  },
  {
    key: "scale",
    label: "Scale",
    eyebrow: "Act III · M09 – M15 · Three directions of growth",
    heading: "Organic. Inorganic. Financial.",
    sub: "Growth came from three directions at once and we managed all three. Each one changed the business model permanently.",
    points: [
      <>
        <strong>Sportstar Round:</strong> India's top-ranked athletes across four sports invested at
        valuation, on commercial terms, not as brand endorsers
      </>,
      <>
        <strong>SPV facility financing:</strong> exclusive partnership with a wealth management
        firm, new centres on third-party capital
      </>,
      <>
        <strong>Centre performance scoreboard:</strong> every location answers to one set of numbers
      </>,
      <>
        <strong>Cross-functional integration:</strong> finance, operations, expansion, and capital
        on one plan, one review
      </>,
    ],
  },
  {
    key: "institution",
    label: "Institution",
    eyebrow: "Act IV · M15 – M24 · Building for the Series A",
    heading: (
      <>
        Prepare for a large raise.{" "}
        <em className="font-serif italic text-orange">Eighteen months out.</em>
      </>
    ),
    sub: "A Series A investor does not buy the last six months. They buy the trajectory. We started building the evidence eighteen months before the first pitch.",
    points: [
      <>
        <strong>All reporting frameworks</strong> running without the founders chasing numbers
      </>,
      <>
        <strong>5+ franchise interests</strong> introduced and active, proving non-dilutive scale
      </>,
      <>
        <strong>Valuation cases</strong> built to survive a hostile investor's questions
      </>,
      <>
        <strong>International expansion plan</strong> costed and sequenced for the use-of-proceeds
        narrative
      </>,
      <>
        <strong>Investor interest managed</strong> before the formal process opened, giving the
        company optionality
      </>,
      <>
        <strong>$13.75m in qualified investor interest</strong> generated for the bridge and Series
        A, both currently in process
      </>,
    ],
  },
  {
    key: "today",
    label: "Today",
    eyebrow: "Month 24 · Seven offices · What we manage today",
    heading: (
      <>
        The relationship, at <em className="font-serif italic text-orange">month twenty-four.</em>
      </>
    ),
    render: () => (
      <div className="mt-8 grid gap-px overflow-hidden rounded-xl border border-paper/10 bg-paper/10 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { id: "strategy" as OfficeId, name: "Strategy", body: "International expansion plan, sequenced for Series A use of proceeds." },
          { id: "cfo" as OfficeId, name: "CFO Office", body: "Reporting frameworks and continuous improvement, self-running." },
          { id: "ib" as OfficeId, name: "Investment Banking", body: "Series A in process. $1.25m bridge committed." },
          { id: "corpdev" as OfficeId, name: "Corporate Development", body: "One closed acquisition. Inorganic pipeline under evaluation." },
          { id: "franchise" as OfficeId, name: "Franchise Office", body: "5+ interests introduced. Optimisation and SOPs behind each." },
          { id: "partnerships" as OfficeId, name: "Partnerships", body: "Facility rollouts on SPV financing. Strategic collaborations ongoing." },
          { id: "ir" as OfficeId, name: "Investor Relations", body: "All investor comms and PR, one narrative, centrally managed." },
        ].map(({ id, name, body }) => (
          <div key={name} className="bg-ink p-5">
            <div className="eyebrow mb-2 inline-flex items-center gap-1.5 text-orange">
              <OfficeLabel id={id} name={name} />
            </div>
            <p className="text-[13px] leading-relaxed text-paper/55">{body}</p>
          </div>
        ))}
      </div>
    ),
  },
  {
    key: "contact",
    label: "Contact",
    eyebrow: "Partners in enterprise value creation",
    heading: (
      <>
        We stay until <em className="font-serif italic text-orange">the numbers move.</em>
      </>
    ),
    sub: "This is a sample early-stage relationship. The same structure scales to a ₹100 to ₹2,000 crore business. We work across Growth, Efficiency, Transactions, and Portfolio Value. One firm, four levers, no handoffs.",
  },
];
