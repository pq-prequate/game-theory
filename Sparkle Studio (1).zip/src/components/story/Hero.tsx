import { motion, useReducedMotion } from "motion/react";
import { useEffect, useState } from "react";
import { CountUp } from "./CountUp";
import { heroStats } from "./data";

const headline = ["Partners", "in", "enterprise value", "creation."];

export function Hero() {
  const reduce = useReducedMotion();
  const [pointer, setPointer] = useState({ x: 0, y: 0 });

  useEffect(() => {
    if (reduce) return;
    const onMove = (e: PointerEvent) => {
      setPointer({
        x: (e.clientX / window.innerWidth - 0.5) * 2,
        y: (e.clientY / window.innerHeight - 0.5) * 2,
      });
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    return () => window.removeEventListener("pointermove", onMove);
  }, [reduce]);

  return (
    <section id="top" className="relative overflow-hidden bg-ink pt-[130px] pb-20 sm:pt-[160px]">
      <motion.div
        aria-hidden
        animate={{ x: pointer.x * 40, y: pointer.y * 30 }}
        transition={{ type: "spring", stiffness: 40, damping: 20 }}
        className="pointer-events-none absolute -top-40 -left-24 size-[520px] rounded-full bg-orange-deep/25 blur-[120px]"
      />
      <motion.div
        aria-hidden
        animate={{ x: pointer.x * -60, y: pointer.y * -40 }}
        transition={{ type: "spring", stiffness: 30, damping: 22 }}
        className="pointer-events-none absolute -right-32 bottom-0 size-[420px] rounded-full bg-orange/15 blur-[130px]"
      />
      <span
        aria-hidden
        className="pointer-events-none absolute -top-16 right-4 font-serif text-[280px] leading-none text-paper/4 select-none sm:text-[420px]"
      >
        24
      </span>

      <div className="relative mx-auto max-w-6xl px-5 sm:px-8">
        <motion.p
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="eyebrow text-orange"
        >
          Sports &amp; Gaming · 24-month engagement story
        </motion.p>

        <h1 className="mt-6 max-w-4xl text-[clamp(38px,6.5vw,84px)] leading-[1.04] font-light text-paper">
          {headline.map((word, i) => (
            <motion.span
              key={word}
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.12 + i * 0.12, duration: 0.6, ease: "easeOut" }}
              className="mr-3 inline-block"
            >
              {word === "enterprise value" ? (
                <span className="emphasis relative text-orange">
                  enterprise value
                  <motion.span
                    initial={{ scaleX: 0 }}
                    animate={{ scaleX: 1 }}
                    transition={{ delay: 0.9, duration: 0.7, ease: "easeOut" }}
                    className="absolute -bottom-1 left-0 h-px w-full origin-left bg-orange/60"
                  />
                </span>
              ) : (
                word
              )}
            </motion.span>
          ))}
        </h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7, duration: 0.8 }}
          className="mt-8 max-w-2xl text-[15px] leading-relaxed text-paper/60 sm:text-base"
        >
          A venture-backed sports and gaming company. No rollout plan, no capital raised, no
          franchise model. We came in at month zero and built the business around the founders.{" "}
          <strong className="font-semibold text-paper">
            Two rounds, one acquisition, seven operating mandates.
          </strong>{" "}
          Twenty-four months and counting.
        </motion.p>

        <div className="mt-16 grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-paper/10 bg-paper/10 lg:grid-cols-4">
          {heroStats.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.9 + i * 0.08 }}
              className="group bg-ink p-6 transition-colors hover:bg-ink-soft"
            >
              <div className="font-serif text-[clamp(34px,4.5vw,52px)] leading-none text-orange transition-transform duration-300 group-hover:-translate-y-0.5">
                <CountUp value={s.value} prefix={s.prefix} suffix={s.suffix} />
              </div>
              <div className="eyebrow mt-3 text-[10px] text-paper/35">{s.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}