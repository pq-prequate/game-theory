import { Wordmark } from "./Wordmark";

export function StoryFooter() {
  return (
    <footer className="border-t border-hairline bg-paper py-10">
      <div className="mx-auto max-w-6xl space-y-4 px-5 sm:px-8">
        <Wordmark />
        <p className="max-w-4xl text-xs leading-relaxed text-grey/70">
          Client identity anonymised under our confidentiality commitments. Figures described are as
          reported at the time of the engagement. Capital described as "qualified interest
          generated" or "in process" has not yet closed. Past work does not guarantee future
          results. © 2026 Prequate Advisory ·{" "}
          <a
            href="https://www.prequateadvisory.com"
            target="_blank"
            rel="noopener"
            className="text-inherit"
          >
            www.prequateadvisory.com
          </a>
        </p>
      </div>
    </footer>
  );
}