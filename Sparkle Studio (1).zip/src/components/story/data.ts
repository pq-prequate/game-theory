import type { LucideIcon } from "lucide-react";
import {
  Calculator,
  Compass,
  GitMerge,
  Handshake,
  Megaphone,
  Store,
  TrendingUp,
} from "lucide-react";

export type OfficeId =
  | "strategy"
  | "cfo"
  | "ib"
  | "corpdev"
  | "franchise"
  | "partnerships"
  | "ir";

export const offices: { id: OfficeId; label: string; icon: LucideIcon }[] = [
  { id: "strategy", label: "Strategy", icon: Compass },
  { id: "cfo", label: "CFO", icon: Calculator },
  { id: "ib", label: "Investment Banking", icon: TrendingUp },
  { id: "corpdev", label: "Corp Dev", icon: GitMerge },
  { id: "franchise", label: "Franchise", icon: Store },
  { id: "partnerships", label: "Partnerships", icon: Handshake },
  { id: "ir", label: "Investor Relations", icon: Megaphone },
];

export type Milestone = {
  month: string;
  office: OfficeId;
  officeLabel: string;
  tag?: string;
  metric?: { value: number; prefix?: string; suffix?: string; label: string };
  title: string;
  body: string;
};

export type EmphasisCallout = {
  office: OfficeId;
  month: string;
  eyebrow: string;
  heading: string;
  body: string;
  steps: string[];
  stats: { value: number | string; prefix?: string; suffix?: string; label: string }[];
};

export type Act = {
  id: string;
  numeral: string;
  span: string;
  heading: string;
  intro: string;
  milestones: Milestone[];
  emphasisCallouts?: EmphasisCallout[];
};

export const heroStats = [
  { value: 24, label: "Months and counting" },
  { value: 7, label: "Standing mandates" },
  { value: 3.75, prefix: "$", suffix: "m", label: "Closed capital · two rounds" },
  { value: 45, label: "Days, M&A signed to closed" },
];

export const maSteps = [
  "Asset sourcing",
  "Vision alignment",
  "Negotiation",
  "Deal structure",
  "Diligence",
  "Integration",
];

export const acts: Act[] = [
  {
    id: "act-1",
    numeral: "I",
    span: "M00 – M06",
    heading: "Build the plan. Then the business.",
    intro:
      "Before the first 5 centres opened or the first large round was raised, we wrote the blueprint. Six months of work that most businesses skip, and most businesses regret skipping. The rollout strategy, the financial model, and the annual plan came out of this phase. It gave the founders a business they could defend in any room.",
    milestones: [
      {
        month: "M00",
        office: "strategy",
        officeLabel: "Strategy Office",
        title: "Business blueprint",
        body: "Market structure, unit economics, and the 24-month sequence of moves, written before a single rupee was committed to growth. This document became the brief for every decision that followed.",
      },
      {
        month: "M03",
        office: "strategy",
        officeLabel: "Strategy Office",
        title: "Rollout strategy",
        body: "Which locations. Which formats. In what order. And the numbers each opening had to hit to justify the next one. Expansion became a schedule, not a debate.",
      },
      {
        month: "M05",
        office: "cfo",
        officeLabel: "CFO Office",
        title: "Annual operating plan and financial model",
        body: "Every hiring decision, every pricing call, every capex commitment traced to one financial model. The founders and the board asked hard questions. The model answered them.",
      },
    ],
  },
  {
    id: "act-2",
    numeral: "II",
    span: "M06 – M09",
    heading: "Raise capital. Build the machine behind it.",
    intro:
      "The plan was in place. Capital followed. We ran the Pre-Series A end to end and used the same window to build the operating infrastructure a funded company needs: a financial excellence framework, a franchise model for non-dilutive scaling, and a single voice managing all investor and public communications.",
    milestones: [
      {
        month: "M06",
        office: "ib",
        officeLabel: "Investment Banking Office",
        metric: { value: 2.5, prefix: "$", suffix: "m", label: "Pre-Series A closed" },
        title: "Pre-Series A: Rainmatter and WEH",
        body: "Negotiation support, structuring, round expansion, valuation defence, and diligence. Closed with two institutional investors. The round set the valuation story for everything that followed.",
      },
      {
        month: "M08",
        office: "franchise",
        officeLabel: "Franchise Office",
        title: "Franchise model",
        body: "Scaling on owned capital alone caps the business. We designed the franchise model from scratch: partner economics, entry criteria, and the operating standards a franchisee signs up for on day one.",
      },
      {
        month: "M09",
        office: "cfo",
        officeLabel: "CFO Office",
        title: "Financial operating excellence framework",
        body: "Reporting rhythms, cost disciplines, and controls built to hold at ten centres as well as they did at two. A framework that does not depend on the founders being in every room.",
      },
      {
        month: "M09",
        office: "ir",
        officeLabel: "Investor Relations",
        tag: "Ongoing",
        title: "Investor relations and PR",
        body: "From month nine, one narrative, managed centrally. All investor communications and public messaging aligned to what the business is about to do next, not what it did last quarter.",
      },
    ],
  },
  {
    id: "act-3",
    numeral: "III",
    span: "M09 – M15",
    heading: "Three directions of growth, at once.",
    intro:
      "Organic growth, inorganic growth, and financial engineering ran in parallel. An acquisition added technology. A second round added credibility. A financing partnership took new centres off the company's balance sheet entirely. The CFO office tied all three together.",
    emphasisCallouts: [
      {
        office: "corpdev",
        month: "M10",
        eyebrow: "Corporate Development Office · M10",
        heading: "Acquired an AI sports technology company in 45 days.",
        body: "The target was an AI-native sports technology platform. We sourced the asset, aligned the two founding teams on vision, structured the transaction, ran diligence, and delivered integration. The deal moved from signed term sheet to closed in 45 days. No advisor sat on the sideline.",
        steps: maSteps,
        stats: [
          { value: 45, label: "Days, signed to closed" },
          { value: 6, label: "Steps owned by one team" },
          { value: "AI-native sports tech", label: "Technology added to the platform" },
        ],
      },
      {
        office: "ib",
        month: "M15",
        eyebrow: "Investment Banking Office · M15 · The Sportstar Round",
        heading: "A round anchored by India's top-ranked athletes, on commercial terms.",
        body: "India's top-ranked athletes across four sports came in at the same valuation, on commercial terms, not as brand endorsers or equity-for-promotion arrangements. That distinction put credibility on the cap table without diluting the commercial logic of the raise.",
        steps: [
          "Solicited the sports stars",
          "Set up the deal",
          "Stitched an accelerated value program",
          "Negotiated the terms",
          "Defended the valuation case",
        ],
        stats: [
          { value: 4, label: "Top-ranked athletes across four sports" },
          { value: 1, label: "Valuation shared by every investor" },
          { value: "Commercial terms", label: "Not brand endorsements or equity-for-promotion" },
        ],
      },
    ],
    milestones: [
      {
        month: "M12",
        office: "ib",
        officeLabel: "Investment Banking Office",
        title: "The Sportstar Round",
        body: "We structured a round anchored by India's top-ranked athletes across four sports. Every investor came in at the same valuation, on commercial terms, not as brand endorsers or equity-for-promotion arrangements. That distinction mattered: it put credibility on the cap table without diluting the commercial logic of the raise.",
      },
      {
        month: "M12",
        office: "cfo",
        officeLabel: "CFO Office",
        title: "Cross-functional engagement",
        body: "Finance, operations, expansion, and capital started working off one plan, reviewed in one room. The CFO office held the integration together as headcount and complexity grew.",
      },
      {
        month: "M13",
        office: "partnerships",
        officeLabel: "Partnerships Office",
        title: "SPV-based facility financing",
        body: "Exclusive partnership with a wealth management firm for SPV-based facility financing. New centres now open on third-party capital, not the company's own. The model changed the unit economics of every opening that followed.",
      },
      {
        month: "M14",
        office: "franchise",
        officeLabel: "Franchise Office",
        title: "Centre performance review mechanism",
        body: "Every centre answers to the same scoreboard. The review mechanism tells leadership which locations earn more capital and which need fixing before they get more.",
      },
    ],
  },
  {
    id: "act-4",
    numeral: "IV",
    span: "M15 – M24",
    heading: "Build for a large raise. Not just the next one.",
    intro:
      "The last phase was about institutional quality. Reporting that runs without pushing. A franchise pipeline generating real demand. Valuation cases built to withstand the scrutiny of a Series A investor. The Series A is in process. The preparation for it started eighteen months before the first pitch.",
    milestones: [
      {
        month: "M16",
        office: "cfo",
        officeLabel: "CFO Office",
        title: "All reporting frameworks, running on their own",
        body: "Continuous process improvement built into the rhythm. The board pack, management reporting, and the review cadence run without the founders chasing numbers from five different systems.",
      },
      {
        month: "M18",
        office: "franchise",
        officeLabel: "Franchise Office",
        tag: "Ongoing",
        metric: { value: 5, suffix: "+", label: "Franchise interests introduced" },
        title: "Taking the franchise model to market",
        body: "Five-plus serious franchise interests introduced and active. Optimisation, efficiency, and SOP rollouts behind each one. The franchise model is now the primary route to non-dilutive scale.",
      },
      {
        month: "M18",
        office: "partnerships",
        officeLabel: "Partnerships Office",
        tag: "Ongoing",
        title: "Facility rollouts and strategic collaborations",
        body: "New facility rollouts and strategic collaborations as a standing mandate. Each opening runs on the SPV financing structure built in month thirteen.",
      },
      {
        month: "M19",
        office: "ib",
        officeLabel: "Investment Banking Office",
        title: "Valuation cases and the international plan",
        body: "Valuation cases that survive a hostile investor's questions. An international expansion plan costed and sequenced. Investor interest managed as it came in, before the formal process opened.",
      },
      {
        month: "M21",
        office: "ib",
        officeLabel: "Investment Banking Office",
        metric: {
          value: 13.75,
          prefix: "$",
          suffix: "m",
          label: "Qualified investor interest generated",
        },
        title: "Bridge and Series A: qualified interest generated",
        body: "Qualified interest generated for a $1.25m bridge and a $12.5m Series A, both currently in process. Twenty-one months after the blueprint, the company enters its largest raise from a position of proof, not promise.",
      },
    ],
  },
];

export const mandates: { officeId: OfficeId; office: string; body: string }[] = [
  {
    officeId: "partnerships",
    office: "Partnerships Office",
    body: "New facility rollouts and strategic collaborations, each one on the SPV financing model we built.",
  },
  {
    officeId: "franchise",
    office: "Franchise Office",
    body: "Five-plus active franchise interests, with optimisation, efficiency, and SOP rollouts behind each.",
  },
  {
    officeId: "cfo",
    office: "CFO Office",
    body: "Reporting frameworks, continuous process improvement, and the financial review rhythm.",
  },
  {
    officeId: "ir",
    office: "Investor Relations",
    body: "All investor communications and public relations, aligned to strategic priorities in real time.",
  },
  {
    officeId: "ib",
    office: "Investment Banking Office",
    body: "$13.75m in qualified investor interest generated. Series A and bridge both in process. International expansion plan ready.",
  },
  {
    officeId: "corpdev",
    office: "Corporate Development Office",
    body: "Inorganic growth opportunities evaluated and structured. One closed acquisition on record.",
  },
  {
    officeId: "strategy",
    office: "Strategy Office",
    body: "The international expansion plan, sequenced and costed. New market entry sequenced for the Series A use of proceeds.",
  },
];

export const monthTicks = [
  { label: "M00", target: "act-1" },
  { label: "M03", target: "act-1" },
  { label: "M06", target: "act-2" },
  { label: "M09", target: "act-2" },
  { label: "M12", target: "act-3" },
  { label: "M15", target: "act-3" },
  { label: "M18", target: "act-4" },
  { label: "M21", target: "act-4" },
  { label: "M24+", target: "mandates" },
];