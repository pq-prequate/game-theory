import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { ChevronDown } from "lucide-react";
import { useRef, useState } from "react";
import { CountUp } from "./CountUp";
import { offices } from "./data";
import type { EmphasisCallout as EmphasisCalloutType } from "./data";

export function EmphasisCallout({
  callout,
  highlight = false,
}: {
  callout: EmphasisCalloutType;
  highlight?: boolean;
}) {
  const reduce = useReducedMotion();
  const [open, setOpen] = useState(false);
  const [orb, setOrb] = useState({ x: 0, y: 0 });
  const ref = useRef<HTMLDivElement>(null);
  const office = offices.find((o) => o.id === callout.office);

  const toggle = () => {
    const next = !open;
    setOpen(next);
    if (next) {
      window.setTimeout(
        () => ref.current?.scrollIntoView({ block: "nearest", behavior: reduce ? "auto" : "smooth" }),
        260,
      );
    }
  };

  return (
    <motion.div
      ref={ref}
      layout
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-8% 0px" }}
      transition={{ duration: 0.6 }}
      exit={{ opacity: 0, y: -12, scale: 0.98 }}
      onPointerMove={(e) => {
        if (reduce) return;
        const r = e.currentTarget.getBoundingClientRect();
        setOrb({ x: e.clientX - r.left, y: e.clientY - r.top });
      }}
      className={`group/callout relative col-span-full overflow-hidden rounded-2xl bg-ink p-7 transition-all duration-300 hover:shadow-[0_30px_70px_-40px_rgba(249,105,0,0.6)] sm:p-10 ${
        highlight ? "ring-2 ring-orange/50" : ""
      }`}
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -top-24 -right-16 size-72 rounded-full bg-orange-deep/20 blur-[100px]"
      />
      <motion.div
        aria-hidden
        animate={{ x: orb.x - 160, y: orb.y - 160 }}
        transition={{ type: "spring", stiffness: 60, damping: 22, mass: 0.6 }}
        className="pointer-events-none absolute top-0 left-0 size-80 rounded-full bg-orange/10 opacity-0 blur-[90px] transition-opacity duration-500 group-hover/callout:opacity-100"
      />
      <div className="relative grid gap-10 lg:grid-cols-[1.4fr_1fr]">
        <div>
          <p className="eyebrow inline-flex items-center gap-1.5 text-orange">
            {office && <office.icon className="size-3.5" />}
            {callout.eyebrow}
          </p>
          <h3 className="emphasis mt-4 text-[clamp(26px,3.4vw,44px)] leading-[1.12] text-paper">
            {callout.heading}
          </h3>
          <p
            className={`mt-4 max-w-xl text-sm leading-relaxed text-paper/55 ${
              open ? "" : "line-clamp-2"
            }`}
          >
            {callout.body}
          </p>

          <AnimatePresence initial={false}>
            {open ? (
              <motion.ol
                key="steps-open"
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: reduce ? 0 : 0.4, ease: "easeOut" }}
                className="relative mt-7 overflow-hidden pl-6"
              >
                <span
                  aria-hidden
                  className="absolute top-2 bottom-2 left-[7px] w-px bg-gradient-to-b from-orange via-orange/40 to-transparent"
                />
                {callout.steps.map((s, i) => (
                  <motion.li
                    key={s}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: reduce ? 0 : 0.06 * i, duration: 0.35 }}
                    className="relative py-2 text-sm text-paper/75"
                  >
                    <span
                      aria-hidden
                      className="absolute top-[15px] -left-6 size-[9px] rounded-full border border-orange bg-ink"
                    />
                    <span className="mr-2 text-[11px] font-semibold text-orange">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    {s}
                  </motion.li>
                ))}
              </motion.ol>
            ) : (
              <motion.div
                key="steps-closed"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="mt-7 flex flex-wrap items-center gap-2"
              >
                {callout.steps.map((s, i) => (
                  <span
                    key={s}
                    className="rounded-full border border-paper/15 px-3 py-1.5 text-[11px] font-semibold text-paper/70 transition-all duration-200 hover:-translate-y-0.5 hover:border-orange hover:text-paper"
                  >
                    <span className="mr-1.5 text-orange">{String(i + 1).padStart(2, "0")}</span>
                    {s}
                  </span>
                ))}
              </motion.div>
            )}
          </AnimatePresence>

          <button
            type="button"
            onClick={toggle}
            aria-expanded={open}
            className="eyebrow mt-7 inline-flex items-center gap-2 rounded-full border border-paper/20 px-4 py-2 text-[10px] text-paper/70 transition-all duration-200 hover:border-orange hover:text-orange"
          >
            {open ? "Collapse" : "Expand the sequence"}
            <ChevronDown className={`size-3.5 transition-transform ${open ? "rotate-180" : ""}`} />
          </button>
        </div>
        <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-1">
          {callout.stats.map((stat, i) => {
            const isNumeric = typeof stat.value === "number";
            return (
              <motion.div
                key={i}
                whileHover={reduce ? {} : { y: -3, scale: 1.02 }}
                transition={{ type: "spring", stiffness: 260, damping: 20 }}
                className={`rounded-lg border p-4 transition-colors duration-200 hover:border-orange hover:bg-paper/[0.03] ${
                  isNumeric ? "border-paper/12" : "border-orange"
                }`}
              >
                <div
                  className={`leading-none text-orange ${
                    isNumeric ? "emphasis text-4xl" : "text-lg font-semibold"
                  }`}
                >
                  {isNumeric ? <CountUp value={stat.value as number} /> : stat.value}
                </div>
                <div className="eyebrow mt-2 text-[10px] text-paper/35">{stat.label}</div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </motion.div>
  );
}
